﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using UnityEngine;

namespace GADERTSPOE
{
    abstract class FactoryBuildingR : Building
    {
        private int unitsToProduce;
        private int gameTicksPerProduction;
        private int[,] spawnPoint;

        public FactoryBuilding(int xPos, int yPos, int health, string faction, string symbol)
            : base(xPos, yPos, health, faction, symbol)
        {
        }

        public Unit SpawnUnits()
        {
            if (unitsToProduce > 0)
            {
                Random rnd = new Random();
                if (rnd.Next(0, 2) == 0)
                {
                    //MeleeUnit
                    MeleeUnit mU = new MeleeUnit(spawnPointX, spawnPointY, 100, -1, true, 1, this.faction, this.symbol, this.name);
                    unitsToProduce--;
                    return mU;
                }
                else
                {
                    //RangedUnit
                    RangedUnit rU = new RangedUnit(spawnPointX, spawnPointY, 100, -1, true, 1, this.faction, this.symbol, this.name);
                    unitsToProduce--;
                    return rU;
                }

            }
            else
                return null;
        }

        public void Save()
        {
            // open the file
            FileStream outFile = new FileStream(@"Files\FactoryBuilding.txt",
                FileMode.Append, FileAccess.Write);
            StreamWriter writer = new StreamWriter(outFile);

            // write to the file
            writer.WriteLine(unitsToProduce);
            writer.WriteLine(gameTicksPerProduction);
            writer.WriteLine(spawnPoint);

            // close the file
            writer.Close();
            outFile.Close();
        }

        public override string toString()
        {
            string output = "X : " + xPos + Environment.NewLine
                + "Y : " + yPos + Environment.NewLine
                + "Health : " + health + Environment.NewLine
                + "Faction : " + faction + Environment.NewLine
                + "Symbol : " + symbol + Environment.NewLine;
            return output;
        }
    }
}
