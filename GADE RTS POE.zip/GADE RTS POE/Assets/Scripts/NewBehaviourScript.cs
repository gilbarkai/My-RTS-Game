﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
    public Rigidbody rb;
    public float accelerationTime = 2f;
    public float maxSpeed = 5f;
    private Vector3 movement;
    private float timeLeft;
    int x, z;

    void Update()
    {
        int r = Random.Range(0, 3);

        if (r == 0)
        {
            x = 1;
            z = 1;
        }
        else if (r == 1)
        {
            x = -1;
            z = 1;
        }   
        else if (r == 2)
        {
            x = 1;
            z = -1;
        } else if (r == 3)
        {
            x = -1;
            z = -1;
        }    


        movement = new Vector3(x, 0, z);
            

        rb.AddForce(movement);

    }
}
