﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace POERTS
{
    public class Map
    {
        private const int MAX_RANDOM_UNITS = 50;
        public const string FIELD_SYMBOL = ".";
        public string[,] grid = new string[20, 20];
        private List<Unit> unitsOnMap = new List<Unit>();
        private int numberOfUnitsOnMap = 0;
        private IEnumerable<Building> buildingsOnMap;

        public string[,] Grid
        {
            get
            {
                return grid;
            }
        }

        private List<Unit> UnitsOnMap()
        {
            return null;
        }

        public void populate()  //Fills map with "."
        {
            for (int i = 0; i == 20; i++)
            {
                for (int j = 0; j == 20; j++)
                {
                    grid[i, j] = ".";
                }
            }
        }

        private void Update(Unit u, int newX, int newY) //Updates the map for every game tick
        {
            if ((newX >= 0 && newX < 20) && (newY >= 0 && newY < 20))
            {
                moveOnMap(u, newX, newY);
                u.move(newX, newY);
            }
        }

        public void checkHealth()
        {
            for (int i = 0; i < numberOfUnitsOnMap; i++)
            {
                if (!unitsOnMap[i].isAlive())
                {
                    grid[unitsOnMap[i].X, unitsOnMap[i].Y] = FIELD_SYMBOL;
                    unitsOnMap.RemoveAt(i);
                    numberOfUnitsOnMap--;
                }
            }
        }

        private void moveOnMap(Unit u, int newX, int newY)
        {
            grid[u.X, u.Y] = FIELD_SYMBOL;
        }

        public void saveMap()
        {
            try
            {
                File.Delete(@"Files\Map.txt");
                File.Delete(@"Files\Map.txt");
                foreach (Unit u in unitsOnMap)
                {
                    u.save();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            try
            {
                File.Delete(@"Files\Map.txt");
                File.Delete(@"Files\Map.txt");
                foreach (Building b in buildingsOnMap)
                {
                    b.save();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

        }

        public void loadMap()
        {
            try
            {
                FileStream inFile = new FileStream(@"Files\MeleeUnit.txt", FileMode.Open, FileAccess.Read);
                StreamReader reader = new StreamReader(inFile);
                input = reader.ReadLine;
                while (input != null)
                {
                    x = int.Parse(input);

                    MeleeUnit mU = new MeleeUnit(x, y, health, speed, attack, attackRange, faction, symbol, name);
                    unitsOnMap.Add(mU);

                    grid[x, y] = mU.Symbol;

                    numberOfUnitsOnMap++;
                    input = reader.ReadLine;
                }
                reader.Close();
                inFile.Close();
            }
            catch (Exception e)
            {
                
            }
        }
    }
}
