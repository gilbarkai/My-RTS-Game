﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using UnityEngine;

namespace GADERTSPOE
{
    abstract class ResourceBuildingR : Building
    {
        private string resourceType;
        private int resourcesPerGameTick;
        private int resourcesRemaining;

        public ResourceBuilding(int x, int y, int health, string faction, string symbol)
            : base(x, y, health, faction, symbol)
        {
        }

        public void GenerateResources()
        {
            if (resourcesRemaining >= 0)
                resourcesRemaining -= resourcesPerGameTick;
        }

        public void Save()
        {
            FileStream outFile = new FileStream(@"Files\ReourceBuilding.txt",
                FileMode.Append, FileAccess.Write);
            StreamWriter writer = new StreamWriter(outFile);

            writer.WriteLine(resourceType);
            writer.WriteLine(resourcesPerGameTick);
            writer.WriteLine(resourcesRemaining);

            writer.Close();
            outFile.Close();
        }

        public override string toString()
        {
            string output = "X : " + x + Environment.NewLine
                + "Y : " + y + Environment.NewLine
                + "Health : " + health + Environment.NewLine
                + "Faction : " + faction + Environment.NewLine
                + "Symbol : " + symbol + Environment.NewLine;
            return output;
        }
    }
}
