﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using UnityEngine;

namespace GADERTSPOE
{
    abstract class RangedUnitB : Unit
    {
        private const int DAMAGE = 1;

        //Constructor
        public RangedUnit(int x, int y, int health, int speed, bool attack, int attackRange, string faction, string symbol, string name)
            : base(x, y, health, speed, attack, attackRange, faction, symbol, name)
        {
        }

        public override void move(int x, int y)
        {
            if (x >= 0 && x < 20)
                X = x;
            if (y >= 0 && y < 20)
                Y = y;
        }

        public override void combat(Unit enemy)
        {
            if (this.isWithinAttackRange(enemy))
            {
                enemy.Health -= DAMAGE;
            }
        }

        public override bool isWithinAttackRange(Unit enemy)
        {
            if (!this.Faction.Equals(enemy.Faction))
            {
                if ((Math.Abs(this.X - enemy.X) <= this.AttackRange) ||
                    (Math.Abs(this.Y - enemy.Y) <= this.AttackRange))
                    return true;
            }
            return false;
        }

        public override Unit nearestUnit(List<Unit> list)
        {
            Unit closest = null;
            int attackRangeX, attackRangeY;
            double range;
            double shortestRange = 1000;

            foreach (Unit u in list)
            {
                attackRangeX = Math.Abs(this.X - u.X);
                attackRangeY = Math.Abs(this.Y - u.Y);

                range = Math.Sqrt(Math.Pow(attackRangeX, 2) + Math.Pow(attackRangeY, 2));

                if (range < shortestRange)
                {
                    shortestRange = range;
                    closest = u;
                }
            }
            return closest;
        }

        public override bool isAlive()
        {
            return (this.Health <= 0);

        }

        public override void save()
        {
            // open the file
            FileStream outFile = new FileStream(@"Files\RangedUnit.txt",
                FileMode.Append, FileAccess.Write);
            StreamWriter writer = new StreamWriter(outFile);

            // write to the file
            writer.WriteLine(x);
            writer.WriteLine(y);
            writer.WriteLine(health);
            writer.WriteLine(speed);
            writer.WriteLine(attack);
            writer.WriteLine(attackRange);
            writer.WriteLine(faction);
            writer.WriteLine(symbol);
            writer.WriteLine(name);

            // close the file
            writer.Close();
            outFile.Close();
        }

        public override string toString()
        {
            string output = "X : " + X + Environment.NewLine
                + "Y : " + Y + Environment.NewLine
                + "Health : " + Health + Environment.NewLine
                + "Speed : " + Speed + Environment.NewLine
                + "Attack : " + (Attack ? "Yes" : "No") + Environment.NewLine
                + "Attack Range : " + AttackRange + Environment.NewLine
                + "Faction : " + Faction + Environment.NewLine
                + "Symbol : " + Symbol + Environment.NewLine;
            return output;
        }
    }
}
