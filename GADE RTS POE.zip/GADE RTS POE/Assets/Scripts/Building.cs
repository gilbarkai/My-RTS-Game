﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace POERTS
{
    abstract class Building
    {
        public int hp;

        Map map = new Map();

        protected int x;
        protected int y;
        protected int health;
        protected string faction;
        protected string symbol;

        public abstract int isAlive();
        public abstract string toString();
        public abstract void save();

        public Building(int x, int y, int health, string faction, string symbol)
        {
            this.x = x;
            this.y = y;
            this.health = health;
            this.faction = faction;
            this.symbol = symbol;
        }

        ~Building()
        {

        }

        public void IsAlive()
        {
            

            if(hp <= 0)
            {
                map.Grid[x, y] = ".";
            }
        }

        
    }

}
