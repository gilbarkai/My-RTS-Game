﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POERTS
{
    class GameEngine
    {
        Map map = new Map();

        public GameEngine()
        {
            map.populate();
        }

        public void start()
        {
            int newX, newY;
            Unit closest;

            map.checkHealth();

            /*for (int j = 0; j < map.UnitsOnMap.Count; j++)
            {
                if (!map.UnitsOnMap)
            }*/
        }

        public void pause()
        {
            //do nothing
        }
    }
}
